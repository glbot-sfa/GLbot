GLbot - Your Study Companion

Features:
- Splash screen
- Custom icon
- Simple login screen
- Supports English, Hindi, and Assamese

Installation:
Open in Sketchware or Android Studio to compile and install.